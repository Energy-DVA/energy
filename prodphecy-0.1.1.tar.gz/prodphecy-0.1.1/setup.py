# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['prodphecy', 'prodphecy.prod', 'prodphecy.type_well']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.19.5,<2.0.0', 'pandas>=1.2.1,<2.0.0']

setup_kwargs = {
    'name': 'prodphecy',
    'version': '0.1.1',
    'description': 'Production forecast methods in petroleum engineering',
    'long_description': None,
    'author': 'zeratul-3011',
    'author_email': 'zeratul.3011@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<4.0.0',
}


setup(**setup_kwargs)
