import numpy as np
import pandas as pd
import warnings
import datetime
from dataclasses import dataclass
from typing import Any
from prodphecy.utils import days_in_month_from_date, is_date
from prodphecy.prod.constants import (
    INSTANTANEOUS_RATE_NAME,
    AVERAGE_RATE_NAME,
    MONTHLY_VOL_NAME,
    CUMULATIVE_VOL_NAME,
    REMAINING_RV_NAME,
    DATES_INDEX_NAME
)


@dataclass
class InputArpsDCA:
    qi: float
    di: float
    b: float
    decline_type: str = "ae"
    end_rate: float = 0.1
    number_of_months: Any = None
    start_date: Any = None
    end_date: Any = None
    downtime: float = 0
    get_summary: bool = True
    report_beginning_of_month: bool = False


@dataclass
class InputDcConv:
    di: float
    b: float
    conversion: str


def decline_conversion(di, b, conversion):
    """

    :param di: decline rate
    :param b: beta exponent
    :param conversion: specify the reference of the decline rate and the one to be
           converted to
    :return: the converted decline rate
    """
    if b == 0:
        return {
            "ae_mn": -np.log((1 - di) ** (1 / 12)),
            "me_mn": -np.log(1 - di),
            "mn_me": 1 - np.exp(-di),
            "mn_ae": 1 - np.exp(-12 * di),
            "ae_me": 1 - (1 - di) ** (1 / 12),
            "me_ae": 1 - (1 - di) ** 12,
        }.get(conversion, None)
    elif b > 0 and b != 1:
        return {
            "ae_mn": ((1 - di) ** -b - 1) / (12 * b),
            "me_mn": (1 / b) * ((1 - b) ** -b - 1),
            "mn_me": 1 - (1 + b * di) ** (-1 / b),
            "mn_ae": 1 - (1 + 12 * b * di) ** (-1 / b),
            "ae_me": 1 - (1 + ((1 - di) ** -b - 1) / 12) ** (-1 / b),
            "me_ae": 1 - (1 + 12 * ((1 - di) ** -b - 1)) ** (-1 / b),
        }.get(conversion, None)
    elif b == 1:
        return {
            "ae_mn": di / (12 * (1 - di)),
            "me_mn": di / (1 - di),
            "mn_me": di / (1 + di),
            "mn_ae": 12 * di / (1 + 12 * di),
            "ae_me": di / (12 - 11 * di),
            "me_ae": 12 * di / (1 + 11 * di),
        }.get(conversion, None)
    else:
        raise ValueError("b value must be positive")


def dca_arps(
    qi,
    di,
    b,
    decline_type="ae",
    end_rate=0.1,
    number_of_months=None,
    start_date=None,
    end_date=None,
    downtime=0,
    get_summary=True,
    report_beginning_of_month=False,
):
    """

    :param qi: The starting point on Y axis, (qi), initial rate.
    :param di: Initial effective decline rate (could annual, or monthly)
    :param b: The degree of curvature of the line
    :param number_of_months: The number of years or months to perform the decline
    :param decline_type: "ae" for annual effective, "me" for monthly effective, "mn"
    for monthly nominal
    :param end_rate:
    :param start_date:
    :param end_date:
    :param downtime:
    :param get_summary:
    :param report_beginning_of_month:
    :return: a numpy array containing the declined rates start from the period right
    after the initial rate (in months)
    """
    number_of_months = None if number_of_months is np.nan else number_of_months
    # Will gather the dates for which to do the forecast. If no date argument is passed,
    # the length of dates will be zero
    dates = pd.DatetimeIndex([])
    # Verify that the forecast can be performed
    if number_of_months is not None and start_date is None:
        warnings.warn(
            "Cumulative volumes will be calculated using an average days per month "
            "during the year (365/12)"
        )
        n_np = np.arange(number_of_months + 1)
    elif start_date is not None and (
        number_of_months is not None or end_date is not None
    ):
        # The initial rate is taking into account one day before the specified
        # start date
        start_date_dt = pd.to_datetime(start_date) - datetime.timedelta(days=1)

        if end_date is None:
            # Adding an additional month to account for calculation due to the initial
            # rate. n is used to calculate the date range
            n = number_of_months + 1
            # Creation of the date range
            dates = pd.date_range(
                start_date_dt, periods=n, freq="M", name=DATES_INDEX_NAME
            )
        else:
            dates = pd.date_range(
                start_date_dt, end_date, freq="M", name=DATES_INDEX_NAME
            )
            n = len(dates)

        # Only insert the first date if it is not already in the date's index
        if start_date_dt != dates[0]:
            # Calculate the number of days for each month
            days_in_month = np.array(list(map(days_in_month_from_date, dates)))
            # Insert the date corresponding to the initial rate to the overall
            # date range
            dates = np.insert(dates, 0, start_date_dt)
            # Calculate the number of production days. In the case the initial rate
            # date does not correspond to the start of the date range, this is added
            # before all the dates, thus it needs to take into account the number of
            # days produced from the initial rate date to the start of the next month
            days_in_prod = np.diff(dates) / np.timedelta64(1, "D")
            # Calculate the fraction of produced days for each month. Effectively,
            # only the first value will be different than 1. Also an additional zero is
            # inserted first to account for initial oil rate value
            days_fraction = np.insert((days_in_prod / days_in_month), 0, 0)
            # Calculate the period vector for the dca by accumulating the sum of the
            # days fraction
            n_np = np.cumsum(days_fraction)
        else:
            n_np = np.arange(n)

    else:
        raise ValueError(
            "Need to specify 'number_of_months' and 'start_date', or the 'start_date' "
            "and 'end_date'.\n If 'end_date' is specified with 'number_of_months', "
            "cums won't take dates into account.\n 'number_of_months' will take "
            "precedence with 'start_date' if 'end_date' is also defined"
        )

    downtime_n = 0 if downtime is None else downtime
    uptime = 1 - downtime_n
    n_np = n_np * uptime
    # Get the monthly nominal decline
    am = {
        "ae": decline_conversion(di, b, "ae_mn"),
        "me": decline_conversion(di, b, "me_mn"),
        "mn": di,
    }.get(decline_type, None)

    if am is None:
        raise ValueError(f"Unrecognized '{decline_type}' for decline type")

    if b == 0:
        q_inst = qi * np.exp(-am * n_np)
    elif b > 0:
        q_inst = qi / ((1 + (b * am * n_np)) ** (1 / b))
    else:
        raise ValueError("b value must be equal or higher than zero")

    # The average rate is calculated using the mid-difference between consecutive
    # instantaneous rates
    q_avg = (
        -np.diff(q_inst) * 0.5 + q_inst[1:]
    )  # This is used to calculate the cumulatives
    # Limit the production according to economic limit
    if end_rate is not None:
        q_avg_limit = np.where(q_avg < end_rate, np.nan, q_avg)
    else:
        q_avg_limit = q_avg
    # Get the indexes where there is nan to check where the economic limit was achieved
    idx_nan = np.argwhere(np.isnan(q_avg_limit))
    idx_nan_start = len(q_avg)
    # Create an identifier if ended by rate or date
    ended_by_rate = False
    if len(idx_nan) > 0:
        # Get the index where the economic limit started
        idx_nan_start = idx_nan[0][0]
        q_avg_limit = q_avg_limit[:idx_nan_start]
        # Limit the instantaneous rate based on the average rate
        # Taken from index 1 to avoid getting the initial rate
        q_inst_limit = q_inst[1: idx_nan_start + 1]
        ended_by_rate = True
    else:
        # Taken from index 1 to avoid getting the initial rate
        q_inst_limit = q_inst[1:]

    if len(dates) > 0:
        # Calculate the # of days in each month to get cumulative volumes
        days_in_dates = np.diff(dates) / np.timedelta64(1, "D")
        month_vol = q_avg_limit * days_in_dates[:idx_nan_start] * uptime
        # Filtering since idx 1 and up to index where nan starts
        index = dates[1: idx_nan_start + 1]
        if report_beginning_of_month:
            index = index - pd.offsets.MonthBegin(1)
    else:
        # Using average number of days in month when dates are not available
        month_vol = q_avg_limit * (365 / 12) * uptime
        index = np.arange(len(month_vol)) + 1

    cum_vol = np.cumsum(month_vol)
    # For remaining reserves just need the last cum minus the cumulative volume
    if len(q_avg_limit) > 0:
        remaining_reserves = cum_vol[-1] - cum_vol
    else:
        remaining_reserves = 0

    if len(q_avg_limit) > 0:
        forecast_data = {
            INSTANTANEOUS_RATE_NAME: q_inst_limit,
            AVERAGE_RATE_NAME: q_avg_limit,
            MONTHLY_VOL_NAME: month_vol,
            CUMULATIVE_VOL_NAME: cum_vol,
            REMAINING_RV_NAME: remaining_reserves,
        }
    else:
        forecast_data = {
            INSTANTANEOUS_RATE_NAME: 0.0,
            AVERAGE_RATE_NAME: 0.0,
            MONTHLY_VOL_NAME: 0.0,
            CUMULATIVE_VOL_NAME: 0.0,
            REMAINING_RV_NAME: 0.0,
        }

        index = dates[1:2] if len(dates) > 0 else [0]

    df_forecast_data = pd.DataFrame(forecast_data, index=index)

    if get_summary:
        summary_data = {
            "b": b,
            "Di_" + decline_type: di,
            "qi": qi,
            "ti": start_date_dt if len(dates) > 0 else None,
            "te": index[-1] if len(index) > 0 else start_date_dt,
            "final_rate": q_inst_limit[-1] if len(q_inst_limit) > 0 else 0,
            "reserves": cum_vol[-1] if len(cum_vol) else 0,
            "forecast_ended_by": "rate" if ended_by_rate else "date",
        }

        df_summary = pd.DataFrame(summary_data, index=[0])

        return df_forecast_data, df_summary

    return df_forecast_data


def batch_dca_forecast(
    dca_data: pd.DataFrame,
    identifier_col,
    qi,
    di,
    b,
    number_of_months=None,
    end_rate=0.1,
    start_date=None,
    end_date=None,
    downtime=None,
    decline_type="ae",
    report_beginning_of_month=False,
    debug=False,
) -> (pd.DataFrame, pd.DataFrame):
    """
    Processes several dca parameter at the time to create a forecast for each entity.
    :param dca_data: The data with the dca parameters
    :param identifier_col: The column name of where the identifiers are defined
    :param qi: The column of the initial rate defined in the dca_data or the value of
    initial rate for all identities
    :param di: The column of initial decline defined in the dca_data or the value for
    all the identifiers
    :param b: The column of the b factor defined in the dca_data or the value for all
    the identifiers
    :param number_of_months: The column of the number of months in the dca_data or the
    value for all identifiers
    :param end_rate: The column for the end_rate in the dca_data or the value for all
    identifiers
    :param start_date: The column for the start_rate in the dca_data or the value for
    all identifiers
    :param end_date: The column for the end_date in the dca_data or the value for all
    identifiers
    :param downtime: The column for the downtime in the dca_data or the value for all
    identifiers
    :param decline_type: Specifies the value of the decline_type as a string. This is
    applied to all identifiers
    :param report_beginning_of_month: If True, the forecast will be reported at the
    beginning of each month
    :param debug: Print rows
    :return: Two data frames, the first one contains the forecast production and the
    second one the summary for all identifiers
    """

    numeric = (int, float)

    qi_is_value = True if isinstance(qi, numeric) or qi is None else False
    di_is_value = True if isinstance(di, numeric) or di is None else False
    b_is_value = True if isinstance(b, numeric) or b is None else False
    n_months_is_value = (
        True
        if isinstance(number_of_months, numeric) or number_of_months is None
        else False
    )
    start_date_is_value = True if is_date(start_date) or start_date is None else False
    end_date_is_value = True if is_date(end_date) or end_date is None else False
    downtime_is_value = (
        True if isinstance(downtime, numeric) or downtime is None else False
    )
    end_rate_is_value = (
        True if isinstance(end_rate, numeric) or end_rate is None else False
    )

    forecast_all = {}
    summary_all = {}

    for idx, row in dca_data.iterrows():
        if debug:
            print(f"Processing values: {row}")
        qi_r = qi if qi_is_value else row[qi]
        di_r = di if di_is_value else row[di]
        b_r = b if b_is_value else row[b]
        n_months_r = number_of_months if n_months_is_value else row[number_of_months]
        start_date_r = start_date if start_date_is_value else row[start_date]
        end_date_r = end_date if end_date_is_value else row[end_date]
        downtime_r = downtime if downtime_is_value else row[downtime]
        end_rate_r = end_rate if end_rate_is_value else row[end_rate]
        # Check if all the parameters related to dca are lists, if so, they are a
        # multi-stage decline forecast
        if all(isinstance(param, list) for param in [qi_r, di_r, b_r, n_months_r]):
            fc, summary = multi_step_dca(
                qi_r,
                di_r,
                b_r,
                n_months_r,
                decline_type,
                start_date_r,
                end_date_r,
                end_rate_r,
                downtime_r,
                get_summary=True,
                report_beginning_of_month=report_beginning_of_month,
            )
        else:
            try:
                fc, summary = dca_arps(
                    qi_r,
                    di_r,
                    b_r,
                    decline_type,
                    end_rate_r,
                    n_months_r,
                    start_date_r,
                    end_date_r,
                    downtime_r,
                    get_summary=True,
                    report_beginning_of_month=report_beginning_of_month,
                )
            except TypeError:
                raise TypeError(
                    f"If multi-staged decline, must provide consistent set of lists "
                    f"for (qi, di, b, n) for {row[identifier_col]}. Otherwise provide "
                    f"column names or scalar values for single decline"
                )

        identifier_col_new = identifier_col
        if identifier_col == "index":
            forecast_all[idx] = fc
            summary_all[idx] = summary
            identifier_col_new = "entity"
        else:
            forecast_all[row[identifier_col]] = fc
            summary_all[row[identifier_col]] = summary

    forecast_df = pd.concat(
        forecast_all, names=[identifier_col_new, DATES_INDEX_NAME]
    ).reset_index()
    summary_df = pd.concat(summary_all).droplevel(1)

    return forecast_df, summary_df


def multi_step_dca(
    qi_l: list,
    di_l: list,
    b_l: list,
    n_months_l: list,
    decline_type="ae",
    start_date=None,
    end_date=None,
    end_rate=0.1,
    downtime=0,
    get_summary=True,
    report_beginning_of_month=False,
):
    """

    :param qi_l:
    :param di_l:
    :param b_l:
    :param n_months_l:
    :param decline_type:
    :param start_date:
    :param end_date:
    :param end_rate:
    :param downtime:
    :param get_summary:
    :param report_beginning_of_month:
    :return:
    """
    if len(qi_l) == len(di_l) == len(b_l) == len(n_months_l):
        previous_cum = 0
        next_start_date = pd.to_datetime(start_date)
        end_date_n = pd.to_datetime(end_date)
        fc_all = pd.DataFrame()
        summ_all = pd.DataFrame()
        last_loop = False
        for idx, (qi, di, b, n) in enumerate(zip(qi_l, di_l, b_l, n_months_l)):
            if next_start_date is not None and idx != len(n_months_l) - 1:
                # Check if the current period will last more than the end_date if
                # it is defined
                decline_period_last_date = next_start_date + pd.offsets.MonthBegin(n)

            if idx == len(n_months_l) - 1 and n is None:
                if end_date is None:
                    raise ValueError(
                        "Need to provided the number of months or the end date for the "
                        "last stage of the decline"
                    )
                else:
                    fc_i, summ_i = dca_arps(
                        qi,
                        di,
                        b,
                        decline_type,
                        end_rate,
                        end_date=end_date_n,
                        start_date=next_start_date,
                        downtime=downtime,
                        get_summary=get_summary,
                        report_beginning_of_month=report_beginning_of_month,
                    )

            elif n is None:
                raise ValueError(
                    "All decline stages need the number of months. The last stage "
                    "can use either the number of months or the end_date"
                )

            elif end_date is not None and next_start_date is not None:
                if decline_period_last_date >= end_date_n:
                    fc_i, summ_i = dca_arps(
                        qi,
                        di,
                        b,
                        decline_type,
                        end_rate,
                        number_of_months=None,
                        start_date=next_start_date,
                        end_date=end_date_n,
                        downtime=downtime,
                        get_summary=get_summary,
                        report_beginning_of_month=report_beginning_of_month,
                    )
                    last_loop = True
                else:
                    fc_i, summ_i = dca_arps(
                        qi,
                        di,
                        b,
                        decline_type,
                        end_rate,
                        n,
                        start_date=next_start_date,
                        downtime=downtime,
                        get_summary=get_summary,
                        report_beginning_of_month=report_beginning_of_month,
                    )
            else:
                fc_i, summ_i = dca_arps(
                    qi,
                    di,
                    b,
                    decline_type,
                    end_rate,
                    n,
                    start_date=next_start_date,
                    downtime=downtime,
                    get_summary=get_summary,
                    report_beginning_of_month=report_beginning_of_month,
                )

            fc_i[CUMULATIVE_VOL_NAME] = fc_i[CUMULATIVE_VOL_NAME] + previous_cum
            fc_all = fc_all.append(fc_i)
            summ_all = summ_all.append(summ_i)

            if last_loop:
                break

            if start_date is not None:
                # Needs to start at the beginning of the next month
                next_start_date = fc_i.index[-1] + pd.offsets.MonthBegin(1)
            else:
                next_start_date = None
            previous_cum = fc_all[CUMULATIVE_VOL_NAME].iloc[-1]

        month_vol = fc_all[MONTHLY_VOL_NAME].values
        cum_vol = np.cumsum(month_vol)
        # For remaining reserves just need the cum in reversed order minus the first
        # monthly volume
        remaining_reserves = cum_vol[::-1] - month_vol[0]
        fc_all[CUMULATIVE_VOL_NAME] = cum_vol
        fc_all[REMAINING_RV_NAME] = remaining_reserves

        summary_data = {
            "b": str(b_l),
            "Di_" + decline_type: str(di_l),
            "qi": str(qi_l),
            "ti": start_date if start_date is not None else None,
            "te": fc_all.index[-1],
            "final_rate": fc_all[AVERAGE_RATE_NAME].iloc[-1],
            "reserves": fc_all[CUMULATIVE_VOL_NAME].iloc[-1],
            "forecast_ended_by": summ_all["forecast_ended_by"].iloc[-1],
        }
        df_summary = pd.DataFrame(summary_data, index=[0])
        if start_date is not None:
            return fc_all, df_summary
        else:
            return fc_all.reset_index(drop=True), df_summary
    else:
        raise IndexError(
            "qi, di, b, and number of months must be list with the same size"
        )



