import pandas as pd
import numpy as np
from prodphecy.utils import days_to_months, is_date
import datetime
from prodphecy.prod.constants import (
    AVERAGE_RATE_NAME,
    MONTHLY_VOL_NAME,
    CUMULATIVE_VOL_NAME,
    REMAINING_RV_NAME,
    DATES_INDEX_NAME
)


def forecast_vector(
        vector_series: pd.Series,
        reinitialize=True,
        number_of_months=None,
        start_date=None,
        start_month=None,
        end_date=None,
        offset_days=None,
        end_rate=0.1,
        downtime=0,
        get_summary=True,
        apply_downtime_to_rates=False,
        auto_reinitialize=False,
) -> (pd.DataFrame, bool):
    """

    :param vector_series:
    :param end_rate:
    :param reinitialize:
    :param number_of_months:
    :param start_date:
    :param start_month:
    :param end_date:
    :param offset_days:
    :param end_rate:
    :param downtime:
    :param get_summary:
    :param apply_downtime_to_rates:
    :param auto_reinitialize: Only works if reinitialize is set to False. If True, it
    will automatically use reinitialization if the offset is positive. Otherwise, it
    won't use reinitialization
    :return:
    """
    vector = vector_series.copy().dropna()

    has_date = False
    vector_has_enough_values = True
    uptime = 1 - downtime

    if isinstance(vector, pd.Series):
        if isinstance(vector.index, pd.DatetimeIndex):
            has_date = True
    else:
        raise TypeError("Vector object is not a pandas Series")

    # Values to use if dates are available
    start_idx = None

    if start_date is not None and number_of_months is not None:
        start_date_n = pd.to_datetime(start_date)
        # To create the date index, an additional month is added after the last one so
        # the cumulatives of the last month can be taken into account
        date_index = pd.date_range(
            start_date, periods=number_of_months + 1, freq="MS", name=DATES_INDEX_NAME
        )
        n_months = number_of_months
    elif start_date is not None and end_date is not None:
        start_date_n = pd.to_datetime(start_date)
        # To create an additional date at the end of the date index it is necessary to
        # increase by one month the end date provided by the user
        end_date_n = pd.to_datetime(end_date) + pd.offsets.MonthBegin(1)
        date_index = pd.date_range(
            start_date_n, end_date_n, freq="MS", name=DATES_INDEX_NAME
        )
        n_months = len(date_index) - 1
    elif start_month is not None and number_of_months is not None:
        start_date_n = vector.index[start_month - 1]
        date_index = pd.date_range(
            start_date_n, periods=number_of_months + 1, freq="MS", name=DATES_INDEX_NAME
        )
        n_months = number_of_months
        start_idx = start_month - 1
    elif start_month is not None and end_date is not None:
        start_date_n = vector.index[start_month - 1]
        end_date_n = pd.to_datetime(end_date) + pd.offsets.MonthBegin(1)
        date_index = pd.date_range(
            start_date_n, end_date_n, freq="MS", name=DATES_INDEX_NAME
        )
        n_months = len(date_index) - 1
        start_idx = start_month - 1
    else:
        raise ValueError(
            "Please provide a combination of (start_date, n_months), (start_date, "
            "end_date), (start_month, n_months), (start_month, end_date) to perform "
            "the forecast"
        )

    if offset_days is not None:
        off_months_n = days_to_months(offset_days)
    else:
        off_months_n = 0

    # Change the index of the vector in case the user had specified an offset in days.
    # This setting will just take effect if the reinitialize option is set to False,
    # otherwise it won't make any difference
    vector.index = vector.index + pd.offsets.MonthBegin(off_months_n)
    # Check if start_date is happening before the moved index with offset
    start_date_before_index = True if start_date_n < vector.index[0] else False
    # Set reinitialize according to start_date_before_index and change start dates
    # and the date_index
    if start_date_before_index and auto_reinitialize:
        reinitialize_n = True
        start_date_n = vector.index[0]
        end_date_new = date_index[-1]
        date_index = pd.date_range(
            start_date_n, end_date_new, freq="MS", name=DATES_INDEX_NAME
        )
        n_months = len(date_index) - 1
    else:
        reinitialize_n = reinitialize

    # Here is where the actual value replacement occur using the provided information
    if not reinitialize_n:
        if start_idx is None:
            if has_date:
                start_idx_array = np.where(vector.index == start_date_n)
                if start_idx_array[0].size == 0:
                    raise ValueError(
                        f"Start date {start_date} could not be found in provided "
                        f"Series to start the forecast"
                    )
                else:
                    start_idx = start_idx_array[0][0]
            elif start_month is not None:
                start_idx = start_month - 1
            else:
                raise ValueError(
                    "When there are no dates in the vector index, the start_month "
                    "argument needs to be provided"
                )
        available_values_from_vector = len(vector) - start_idx
        rates = np.array(vector[start_idx : start_idx + n_months])
    else:
        available_values_from_vector = len(vector)
        rates = np.array(vector[:n_months])

    if available_values_from_vector < n_months:
        vector_has_enough_values = False
        n_fill_zeros = n_months - len(rates)
        rates = np.append(rates, np.zeros(n_fill_zeros))

    # Calculate additional values from the rates
    # Limit the production according to economic limit
    if end_rate is not None:
        q_avg_limit = np.where(rates < end_rate, np.nan, rates)
    else:
        q_avg_limit = rates

    idx_nan = np.argwhere(np.isnan(q_avg_limit))
    idx_nan_start = len(rates)
    # Create an identifier if ended by rate or date
    ended_by_rate = False
    if len(idx_nan) > 0:
        idx_nan_start = idx_nan[0][0]
        q_avg_limit = q_avg_limit[:idx_nan_start]
        ended_by_rate = True

    if apply_downtime_to_rates:
        q_avg_limit = q_avg_limit * uptime
        uptime = 1

    # Calculate the # of days in each month to get cumulative volumes
    days_in_dates = np.diff(date_index) / np.timedelta64(1, "D")
    month_vol = q_avg_limit * days_in_dates[:idx_nan_start] * uptime
    index = date_index[
            :idx_nan_start
            ]  # Filtering since idx 1 and up to index where nan starts

    cum_vol = np.cumsum(month_vol)
    # For remaining reserves just need the cum in reversed order minus the first
    # monthly volume
    remaining_reserves = cum_vol[-1] - cum_vol

    forecast_data = {
        AVERAGE_RATE_NAME: q_avg_limit,
        MONTHLY_VOL_NAME: month_vol,
        CUMULATIVE_VOL_NAME: cum_vol,
        REMAINING_RV_NAME: remaining_reserves,
    }

    df_forecast_data = pd.DataFrame(forecast_data, index=index)

    if get_summary:
        summary_data = {
            "qi": q_avg_limit[0],
            "ti": start_date_n if len(date_index) > 0 else None,
            "te": index[-1],
            "final_rate": q_avg_limit[-1],
            "reserves": cum_vol[-1],
            "forecast_ended_by": "rate" if ended_by_rate else "date",
            "had_all_data": vector_has_enough_values,
            "offset_months": off_months_n,
        }

        df_summary = pd.DataFrame(summary_data, index=[0])

        return df_forecast_data, df_summary

    return df_forecast_data, vector_has_enough_values


def batch_vector_forecast(
        vector_data: pd.DataFrame,
        rate_vector_col: str,
        identifier_vector_col: str,
        forecast_parameters: pd.DataFrame = None,
        identifier_forecast_col: str = None,
        reinitialize=True,
        number_of_months=None,
        start_date=None,
        start_month=None,
        end_date=None,
        offset_days=None,
        end_rate=0.1,
        downtime=0,
        apply_downtime_to_rates=False,
        auto_reinitialize=False,
) -> (pd.DataFrame, bool):

    """

    :param vector_data:
    :param forecast_parameters:
    :param rate_vector_col:
    :param identifier_vector_col:
    :param identifier_forecast_col:
    :param reinitialize:
    :param number_of_months:
    :param start_date:
    :param start_month:
    :param end_date:
    :param offset_days:
    :param end_rate:
    :param downtime:
    :param apply_downtime_to_rates:
    :param auto_reinitialize:
    :return:
    """

    numeric = (int, float)
    numeric_timedelta = (int, float, datetime.timedelta)

    reinitialize_is_bool = True if isinstance(reinitialize, bool) else False
    n_months_is_value = (
        True
        if isinstance(number_of_months, numeric) or number_of_months is None
        else False
    )
    start_date_is_value = True if is_date(start_date) or start_date is None else False
    start_month_is_value = (
        True if isinstance(start_month, numeric) or start_month is None else False
    )
    end_date_is_value = True if is_date(end_date) or end_date is None else False
    offset_days_is_value = (
        True
        if isinstance(offset_days, numeric_timedelta) or offset_days is None
        else False
    )
    downtime_is_value = (
        True if isinstance(downtime, numeric) or downtime is None else False
    )
    end_rate_is_value = (
        True if isinstance(end_rate, numeric) or end_rate is None else False
    )
    auto_reinitialize_is_bool = True if isinstance(auto_reinitialize, bool) else False

    forecast_all = {}
    summary_all = {}

    if forecast_parameters is not None:
        # Get the unique identifiers from the vector data and check the length is the
        # same as forecast parameters
        unique_ids_vector = set(vector_data[identifier_vector_col])
        if len(forecast_parameters) == len(unique_ids_vector):
            for idx, row in forecast_parameters.iterrows():
                reinitialize_r = (
                    reinitialize if reinitialize_is_bool else row[reinitialize]
                )
                n_months_r = (
                    number_of_months if n_months_is_value else row[number_of_months]
                )
                start_date_r = start_date if start_date_is_value else row[start_date]
                start_month_r = (
                    start_month if start_month_is_value else row[start_month]
                )
                end_date_r = end_date if end_date_is_value else row[end_date]
                offset_days_r = (
                    offset_days if offset_days_is_value else row[offset_days]
                )
                downtime_r = downtime if downtime_is_value else row[downtime]
                end_rate_r = end_rate if end_rate_is_value else row[end_rate]
                auto_reinitialize_r = (
                    auto_reinitialize
                    if auto_reinitialize_is_bool
                    else row[auto_reinitialize]
                )
                identifier = row[identifier_forecast_col]
                vector_for_id = vector_data.loc[
                    vector_data[identifier_vector_col] == identifier, rate_vector_col
                ]

                fc, summary = forecast_vector(
                    vector_for_id,
                    reinitialize_r,
                    n_months_r,
                    start_date_r,
                    start_month_r,
                    end_date_r,
                    offset_days_r,
                    end_rate_r,
                    downtime_r,
                    get_summary=True,
                    apply_downtime_to_rates=apply_downtime_to_rates,
                    auto_reinitialize=auto_reinitialize_r,
                )

                forecast_all[row[identifier_forecast_col]] = fc
                summary_all[row[identifier_forecast_col]] = summary
        else:
            raise ValueError(
                f'Length of unique ids in vector data "{len(unique_ids_vector)}" and '
                f"the forecast is not the same as in the forecast parameters "
                f'"{len(forecast_parameters)}"'
            )

    else:
        if all(
                [
                    reinitialize_is_bool,
                    n_months_is_value,
                    start_date_is_value,
                    start_month_is_value,
                    end_date_is_value,
                    downtime_is_value,
                    end_rate_is_value,
                    auto_reinitialize_is_bool,
                ]
        ):
            gr_vector = vector_data.groupby(identifier_vector_col)[rate_vector_col]
            for name, group in gr_vector:
                fc, summary = forecast_vector(
                    group,
                    reinitialize=reinitialize,
                    number_of_months=number_of_months,
                    start_date=start_date,
                    start_month=start_month,
                    end_date=end_date,
                    end_rate=end_rate,
                    downtime=downtime,
                    get_summary=True,
                    offset_days=offset_days,
                    apply_downtime_to_rates=apply_downtime_to_rates,
                    auto_reinitialize=auto_reinitialize,
                )
                forecast_all[name] = fc
                summary_all[name] = summary
        else:
            raise ValueError(
                "To use the forecast without specifying the parameters in a data "
                "frame, the necessary arguments should be in numeric or date format"
            )

    forecast_df = pd.concat(
        forecast_all, names=[identifier_vector_col, DATES_INDEX_NAME]
    ).reset_index()
    summary_df = pd.concat(summary_all).droplevel(1)
    return forecast_df, summary_df