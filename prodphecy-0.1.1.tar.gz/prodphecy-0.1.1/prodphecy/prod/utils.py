import pandas as pd
import numpy as np
import datetime
from prodphecy.utils import is_date
from prodphecy.prod.constants import (
    AVERAGE_RATE_NAME,
    MONTHLY_VOL_NAME,
    CUMULATIVE_VOL_NAME,
    REMAINING_RV_NAME,
)
from typing import Union, List, Optional, Sequence


def normalize_date_freq(
    df: Union[pd.DataFrame, pd.Series],
    freq: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    cols_fill_na: Optional[Sequence[str]] = None,
    method_no_cols: Optional[str] = None,
    fill_na: Union[int, float] = np.nan,
):
    """
    Returns a new dataframe with a new DateTimeIndex which has a predefined frequency.
    Using this function will ensure there is always a frequency associated to the index
    of this dataframe.

    Parameters
    ----------
    df: pandas DataFrame or Series
        A pandas DataFrame or Series whose index is of type DateTimeIndex
    freq: str
        A string representing the target frequency for the dataframe.
    start_date
        Specify the start date to reindex the dates. If not specified, the earliest date
        in the index will be used
    end_date
        Specify the end date to reindex the dates. If not specified, the latest date
        in the index will be used
    cols_fill_na
        Data Frame columns to fill with values specified in the argument fill_na
    method_no_cols
        {None, ‘backfill’/’bfill’, ‘pad’/’ffill’, ‘nearest’}
        The method to use with other columns not specified in cols_fill_na. The options
        are passed to the pandas.reindex method.
    fill_na: scalar, default np.nan
        Value to use for missing values after the reindexing.

    Returns
    -------
    Series/DataFrame with changed index based on the new frequency. The new dataframe
    will be sorted by its index.
    """

    if isinstance(df, (pd.DataFrame, pd.Series)):
        if isinstance(df.index, pd.DatetimeIndex):
            # Check for duplicate values in index
            if len(df.index) != len(set(df.index)):
                error_message = f"""
                The DateTimeIndex contains duplicate values\n
                Please, provide dates that are unique for each production information\n
                Printing the first rows of the dataframe:\n
                {df.head()}
                """
                raise IndexError(error_message)
            # First we need to sort the dataframe based on its index to get the start
            # and end dates, just in case.
            sorted_df: pd.DataFrame = df.sort_index()
            start_date_n = (
                sorted_df.index[0] if start_date is None else pd.to_datetime(start_date)
            )
            end_date_n = (
                sorted_df.index[-1] if end_date is None else pd.to_datetime(end_date)
            )
        else:
            raise IndexError(
                "The index in the DataFrame or Series should be a "
                "DateTimeIndex object"
            )
    else:
        raise TypeError("First argument should be a pandas DataFrame or Series")

    new_index = pd.date_range(start_date_n, end_date_n, freq=freq, name=df.index.name)
    if cols_fill_na is not None:
        # First reindex the columns that are specified in the cols_fill_na argument
        # These columns will default to nan where new dates appear, and will be replaced
        # with the fill_na value
        df_cols = (
            sorted_df[cols_fill_na].reindex(new_index, fill_value=fill_na).reset_index()
        )
        # Reindex the remaining columns, this time by using the method_co_cols argument
        # as input argument to reindex 'method' argument.
        df_no_cols = (
            sorted_df[sorted_df.columns.difference(cols_fill_na)]
            .reindex(new_index, method=method_no_cols)
            .reset_index(drop=True)
        )

        df_concat = pd.concat([df_cols, df_no_cols], axis=1)
        df_concat.set_index(df.index.name, inplace=True)
        # Use the same column order as the original dataframe
        df_concat = df_concat[df.columns]
        return df_concat
    else:
        return sorted_df.reindex(new_index, fill_value=fill_na)


def calculate_rate_volumes(vector: pd.Series) -> pd.DataFrame:
    """
    Calculates monthly, cumulative and remaining recoverable volumes from a pandas
    series with the average rates and dates as index
    :param vector: pandas Series with average rates and dates as index
    :return: returns a pandas data frame with the calculated monthly, cumulative and
    remaining volumes
    """
    has_date = False

    if isinstance(vector, pd.Series):
        if isinstance(vector.index, pd.DatetimeIndex):
            has_date = True
    else:
        raise TypeError("Vector object is not a pandas Series")

    if has_date:
        # Add an additional date at the beginning of the month to count for the days
        # in the last month
        index_st = vector.index.append(
            pd.DatetimeIndex([vector.index.max() + pd.offsets.MonthBegin(1)])
        )
        # Calculate the # of days in each month to get cumulative volumes
        days_in_dates = np.diff(index_st) / np.timedelta64(1, "D")
        month_vol = vector * days_in_dates
        index = index_st[:-1]
    else:
        index = vector.index
        month_vol = vector * (365 / 12)

    cum_vol = np.cumsum(month_vol)
    # For remaining reserves just need the cum in reversed order minus the first
    # monthly volume
    remaining_reserves = cum_vol[-1] - cum_vol

    calculated_data = {
        AVERAGE_RATE_NAME: vector,
        MONTHLY_VOL_NAME: month_vol,
        CUMULATIVE_VOL_NAME: cum_vol,
        REMAINING_RV_NAME: remaining_reserves,
    }

    result = pd.DataFrame(calculated_data, index=index)
    result.index.name = vector.index.name
    return result


def batch_rate_volume_calc(
    data: pd.DataFrame, rate_col: str, id_col: str, date_col: str
):
    results_header = [
        id_col,
        date_col,
        AVERAGE_RATE_NAME,
        MONTHLY_VOL_NAME,
        CUMULATIVE_VOL_NAME,
        REMAINING_RV_NAME,
    ]
    df = data.copy()
    df.set_index(date_col, inplace=True)
    gr_df = df.groupby(id_col)[rate_col]
    result = pd.DataFrame(columns=results_header)
    result.set_index(date_col, inplace=True)
    for name, group in gr_df:
        partial_result = calculate_rate_volumes(group)
        partial_result[id_col] = name
        cols_ordered = [id_col] + partial_result.columns.to_list()[:-1]
        result = result.append(partial_result[cols_ordered])

    result.reset_index(inplace=True)
    return result


def tidy_dca_info(
    info: pd.DataFrame,
    entity_cols,
    qi_col,
    di_col,
    b_col,
    date_col,
    normalize_dates=True,
):
    n_col = "n"
    # Get all the columns to construct the data frame
    cols = [*entity_cols, qi_col, di_col, b_col, n_col]
    # Create empty lists according to the number of cols
    empty_lists = [[] for _ in cols]
    # Construct the dictionary that will hold the converted data frame information
    data = dict(zip(cols, empty_lists))
    gr_info = info.groupby(entity_cols)
    for names, group in gr_info:

        for idx, col in enumerate(entity_cols):
            data[col].append(names[idx])

        if len(group) > 1:
            qi_list = []
            di_list = []
            b_list = []
            n_list = []
            for index in range(len(group)):
                qi_list.append(group[qi_col].iloc[index])
                di_list.append(group[di_col].iloc[index])
                b_list.append(group[b_col].iloc[index])
                date: datetime = pd.to_datetime(group[date_col].iloc[index])
                month_diff = None
                # Checking if it is the last iteration thus taking care of not
                # selecting an index out of bounds
                try:
                    date_next: datetime = pd.to_datetime(
                        group[date_col].iloc[index + 1]
                    )
                    # This is to ensure the dates start at the beginning of the month
                    # which is the most probable use case related to dca reports
                    if normalize_dates:
                        date = date + pd.offsets.MonthBegin(1)
                        date_next = date_next + pd.offsets.MonthBegin(1)
                    if is_date(date_next) & is_date(date):
                        month_diff = round((date_next - date) / np.timedelta64(1, "M"))
                        n_list.append(month_diff)
                except IndexError:
                    n_list.append(month_diff)

            data[qi_col].append(qi_list)
            data[di_col].append(di_list)
            data[b_col].append(b_list)
            data[n_col].append(n_list)

        else:
            data[qi_col].append(group[qi_col].values[0])
            data[di_col].append(group[di_col].values[0])
            data[b_col].append(group[b_col].values[0])
            data[n_col].append(None)

    return pd.DataFrame(data)
