INSTANTANEOUS_RATE_NAME = "inst_rate"
AVERAGE_RATE_NAME = "avg_rate"
MONTHLY_VOL_NAME = "month_vol"
CUMULATIVE_VOL_NAME = "cum_vol"
REMAINING_RV_NAME = "rem_rv"

forecast_data_template = {
    INSTANTANEOUS_RATE_NAME: [],
    AVERAGE_RATE_NAME: [],
    MONTHLY_VOL_NAME: [],
    CUMULATIVE_VOL_NAME: [],
    REMAINING_RV_NAME: [],
}

DATES_INDEX_NAME = "date"

summary_data_template = {
    "b": None,
    "Di": None,
    "qi": None,
    "ti": None,
    "te": None,
    "final_rate": None,
    "reserves": None,
    "forecast_ended_by": None,
}

START_DATE, END_DATE = "start_date", "end_rate"