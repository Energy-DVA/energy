import pandas as pd
from typing import Union, Optional, Dict
from calendar import monthrange
import datetime
from prodphecy.utils import get_numeric_cols

# Define the name of the column calendar days
_CAL_DAYS_COL = "cal_days"
_CAL_DAY_RATE = "cal_day_rate"


def cal_days_from_date(date: datetime.datetime):
    return float(monthrange(date.year, date.month)[1])


def cal_day_rate(
        volume: Union[pd.Series, pd.DataFrame],
        cols: Optional[list] = None,
        suffix: str = "_rate",
):
    """
    Calculates the calendar rate of the columns in the provided dataframe. This function
    uses the index of the dataframe to calculate the number of days in the month. It
    assumes that the index has a monthly frequency.

    Parameters
    ----------
    volume
        A pandas Series or DataFrame object with the production volume per month. If the
        'cols' argument is not specified, the calendar day rate will be calculated in
        all the numeric columns of the dataframe.
    cols
        The columns of the volume dataframe on which to calculate the rates.
    suffix
        The suffix to append to the columns used for calculating the calendar rate.

    Returns
    -------
    A copy of the pandas Series or DataFrame with the calculated calendar day rates as
    additional columns with the provided suffix
    """

    if isinstance(volume, (pd.Series, pd.DataFrame)):
        # First convert to a dataframe in case this a series object
        df = pd.DataFrame(volume.copy())
        cols = get_numeric_cols(df) if cols is None else cols
        if isinstance(volume.index, pd.DatetimeIndex):
            # Change the column names using the suffix
            new_cols = list(map(lambda x: x + suffix, cols))
            # Calculate the days in the month
            df[_CAL_DAYS_COL] = df.index.map(cal_days_from_date)
            # Calculate the calendar day rate
            df[new_cols] = df[cols].divide(df[_CAL_DAYS_COL], axis=0)
            df.drop(_CAL_DAYS_COL, axis=1, inplace=True)
        else:
            raise IndexError("The index of the Series or DataFrame should be a "
                             "DateTimeIndex")
        if isinstance(volume, pd.Series):
            return pd.Series(df)
        else:
            return df
    else:
        raise TypeError("The volumes argument must be a pandas Series or DataFrame")


def cum_vol(
        df: Union[pd.Series, pd.DataFrame],
        input_type: str = "volume",
        cols: Optional[list] = None,
        suffix: str = "_cum",
):
    """
    Calculates the cumulative volume

    Parameters
    ----------
    df
        A pandas Series or DataFrame that contains the monthly volume or rate
        information. It may optionally have a DateTimeIndex in case the passed values
        ar of type "rate", to calculate the monthly volumes and later the cumulatives
    input_type
        The type of input on which to apply the cumulative sum. It could be "volume" or
        "rate". If "cal_day_rate" and if the df.index is of type DateTimeIndex,
        the monthly volume will be calculated first to apply the cumulative sum. 
        If the index is not a DateTimeIndex, an average number of days per month will 
        be used (365/12)
    cols
        Optionally specify the columns on which to calculate the cumulatives
    suffix
        The suffix to append to the columns used for calculating the cumulative.

    Returns
    -------
    A copy of the pandas Series or DataFrame with the calculate cumulatives as
    additional columns in the dataframe with the provided suffix
    """

    if isinstance(df, (pd.Series, pd.DataFrame)):
        df_n = pd.DataFrame(df.copy())
        # Get numeric cols if necessary
        cols = get_numeric_cols(df_n) if cols is None else cols
        # Change the column names using the suffix
        new_cols = list(map(lambda x: x + suffix, cols))
        # Check if df index is of type DateTimeIndex
        has_dt_idx = isinstance(df.index, pd.DatetimeIndex)
        # Sort the data frame by its index if has DateTimeIndex
        df_n = df_n.sort_index() if has_dt_idx else df_n
        # Calculate the cumulative sums
        if input_type == "volume":
            df_n[new_cols] = df_n[cols].cumsum()
        elif input_type == "rate":
            # Calculate the calendar days to multiply by
            if has_dt_idx:
                # Calculate the calendar days
                df_n[_CAL_DAYS_COL] = df.index.map(cal_days_from_date)
            else:
                df_n[_CAL_DAYS_COL] = 365 / 12  # Use average days per month
            # Calculate the monthly volume
            df_n[new_cols] = df_n[cols].multiply(df_n[_CAL_DAYS_COL], axis=0)
            # Calculate the cumulate sum
            df_n[new_cols] = df_n[new_cols].cumsum()
            # Delete the additional cal days column
            df_n.drop(_CAL_DAYS_COL, axis=1, inplace=True)

        if isinstance(df, pd.Series):
            return pd.Series(df_n)
        else:
            return df_n
    else:
        raise TypeError("The volumes argument must be a pandas Series or DataFrame")