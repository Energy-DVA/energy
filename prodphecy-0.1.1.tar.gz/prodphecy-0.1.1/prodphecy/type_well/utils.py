import pandas as pd
from typing import Optional, Union
from prodphecy.prod.utils import normalize_date_freq
import numpy as np

START_DATE = "start_date"
END_DATE = "end_date"


def prod_periods(prod: pd.Series,
                 inter_period: Optional[int] = None,
                 normalize_freq: bool = False,
                 freq: Optional[str] = None):
    """
    Creates a dataframe with the production periods from the input pandas Series.
    The production periods are calculated when the values of the series are non-zero
    and there is a minimum inter-period time.

    Parameters
    ----------
    prod:
        A pandas Series with a DateTimeIndex object as Index that contains the
        production information of an entity. The index should have a predefined
        frequency, otherwise the input data is not valid.
    inter_period:
        An integer specifying the minimum time between periods. The default
        behavior is to define new periods of production after one value is zero.
    normalize_freq:
        True if input Series' Index Frequency needs to be normalized prior to
        calculating the production periods
    freq:
        If normalize_freq = True, this argument specifies the frequency string given to
        the normalize_date_freq function.

    Returns
    -------
    A pandas DataFrame with the number of periods and the start and end date of those
    production periods
    """

    prod_n = prod.copy().sort_index()

    if isinstance(prod, pd.Series):
        if isinstance(prod.index, pd.DatetimeIndex):
            if normalize_freq:
                if freq is not None:
                    # Will fill the nan values after reindexing with zero
                    prod_n = normalize_date_freq(prod, freq, fill_na=0)
                else:
                    raise ValueError("Need to specify 'freq' argument if the input "
                                     "series will be normalized")
            else:
                try:
                    freq_user = pd.infer_freq(prod.index)
                    if freq_user is None:
                        raise IndexError("Cannot determine the frequency of the series "
                                         "index. Try using the normalize_freq option")
                # If the data has less than 3 points this will give an exception
                # For this case we will let it pass
                except ValueError:
                    pass
        else:
            raise IndexError(
                "The index in the pandas Series should be a DateTimeIndex object"
            )
    else:
        raise TypeError("First argument should be a pandas Series")

    cond_col = "condition"
    periods_col = "periods"

    df = pd.DataFrame()
    # Eliminate leading zeros if they exist from production series
    prod_n = np.trim_zeros(prod_n)
    # Get the condition that the production is equal zero
    df[cond_col] = prod_n == 0
    # Compute the periods where there is difference between production and closing
    # production periods
    df[periods_col] = ((df[cond_col].shift(1) != df[cond_col])
                       .astype(int)
                       .cumsum())
    # Count the months (or any other frequency) where the production is zero for each
    # period of no production
    df_periods = (df[df[cond_col]]
                  .groupby(periods_col)
                  .count()
                  .reset_index())
    # Get the periods where the minimum inter-period condition is not met (this is a
    # pandas series)
    changed_periods = df_periods.loc[
        df_periods[cond_col] < inter_period, periods_col
    ]
    # Replace with False where the periods belong to the "changed_periods" series
    # calculated in the previous step.
    df.loc[df[periods_col].isin(changed_periods), cond_col] = False
    # Recalculate the periods based on the updated condition
    df[periods_col] = ((df[cond_col].shift(1) != df[cond_col])
                       .astype(int)
                       .cumsum())

    # Get the period number, start and end dates for each period.
    # Group by the production periods only
    gr = df[~df[cond_col]].groupby(periods_col)
    # Initialize a dictionary that will store the results
    results = {periods_col: [], START_DATE: [], END_DATE: []}
    for period, group in gr:
        # Convert from odd number to normal sequence
        actual_period = int((period + 1) / 2)
        results[periods_col].append(actual_period)
        results[START_DATE].append(group.index[0])
        results[END_DATE].append(group.index[-1])

    return pd.DataFrame(results)


def batch_prod_periods(df: pd.DataFrame,
                       entity_col: str,
                       prod_col: str,
                       inter_period: Optional[int] = None,
                       normalize_freq: bool = False,
                       freq: Optional[str] = None):
    """
    This is the "batch" version of prod_periods function. This function can be applied
    to a DataFrame containing production profiles and defined by entities. The index of
    the DataFrame should be a DateTimeIndex object.

    Parameters
    ----------
    df:
        A pandas DataFrame containing the production information, the entities for each
        production profile. The index of the DataFrame should be a DataTimeIndex object.
    entity_col:
        The entity column to identify the entities on which the results will be reported
    prod_col:
        The production column to analyze the production periods
    inter_period:
        An integer specifying the minimum time between periods. The default
        behavior is to define new periods of production after one value is zero.
    normalize_freq:
        True if input Series' Index Frequency needs to be normalized prior to
        calculating the production periods
    freq:
        If normalize_freq = True, this argument specifies the frequency string given to
        the normalize_date_freq function.

    Returns
    -------
    A pandas DataFrame with the number of periods and the start and end date of those
    production periods per entity.

    """

    if isinstance(df, pd.DataFrame):
        if isinstance(df.index, pd.DatetimeIndex):
            pass
        else:
            raise IndexError(
                "The index in the pandas DataFrame should be a DateTimeIndex object"
            )
    else:
        raise TypeError("First argument should be a pandas Dataframe")

    gr = df[[entity_col, prod_col]].groupby(entity_col)

    result = pd.DataFrame()
    for entity, prod in gr:
        periods = prod_periods(prod[prod_col], inter_period, normalize_freq, freq)
        periods[entity_col] = entity
        result = result.append(periods)

    # reorder the columns upon return
    return result[[entity_col] + list(result.columns[:-1])].reset_index(drop=True)


def normalize_prod(df=Union[pd.DataFrame, pd.Series]):
    """
    Normalize the date dimension for the entity in the dataframe. This function can be
    used to create a normalized time column and assign it to an existing data frame.

    Parameters
    ----------
    df:
        A pandas DataFrame or Series that will be used as reference to create the
        normalized column.

    Returns
    -------
    A pandas Series with the normalized time column and the index compliant with the
    provided DataFrame

    """

    if isinstance(df, (pd.DataFrame, pd.Series)):
        if len(df) > 0:
            # Using a pandas series to make sure the correct values are assigned to
            # the corresponding indices
            return pd.Series(np.arange(len(df)) + 1, index=df.index)
        else:
            raise IndexError("Can't create a normalized series with no data in the "
                             "provided dataframe or series object")
    else:
        raise TypeError("Must provide a pandas DataFrame or Series")
