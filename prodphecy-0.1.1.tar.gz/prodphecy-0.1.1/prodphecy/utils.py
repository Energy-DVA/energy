import datetime
import pandas as pd
from calendar import monthrange
from typing import List


def days_in_month_from_date(date: datetime.datetime):
    return float(monthrange(date.year, date.month)[1])


def days_to_months(days):
    if isinstance(days, datetime.timedelta):
        months = round(days.days / (365 / 12))
    else:
        months = round(days / (365 / 12))

    return months


def is_date(date):
    try:
        pd.to_datetime(date)
        return True
    except ValueError:
        return False


def closest_start_month(date: datetime.datetime):
    day_date = date.day
    if day_date != 1:
        days_in_month = days_in_month_from_date(date)
        ratio = day_date / days_in_month
        if ratio >= 0.5:
            return date + pd.offsets.MonthBegin(1)
        else:
            return date - pd.offsets.MonthBegin(1)
    else:
        return date


def get_numeric_cols(df: pd.DataFrame) -> List[str]:
    """Determines which columns are numeric in a pandas data frame."""
    numeric_types = ["int64", "float64"]
    df_dtypes_str = df.dtypes.apply(lambda x: x.name)
    is_numeric = df_dtypes_str.isin(numeric_types)
    return list(df_dtypes_str.index[is_numeric])
